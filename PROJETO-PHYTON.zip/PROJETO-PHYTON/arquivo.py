ARQ_USUARIOS = "usuarios.txt"
ARQ_VIDEOS = "videos.txt"
ARQ_FAVORITOS = "favoritos.txt"


def linha():
    print("-" * 40)


# ================= USUÁRIOS =================

def cadastroUser():
    linha()
    print("CADASTRO DE USUÁRIO")
    linha()

    usuario = input("Digite o nome do usuário: ").strip()
    senha = input("Digite sua senha: ").strip()

    open(ARQ_USUARIOS, "a").close()

    arquivo = open(ARQ_USUARIOS, "r")
    linhas = arquivo.readlines()
    arquivo.close()

    for l in linhas:
        partes = l.strip().split(";")
        if len(partes) >= 2:
            if partes[0] == usuario:
                print("Usuário já existe!")
                return

    arquivo = open(ARQ_USUARIOS, "a")
    arquivo.write(usuario + ";" + senha + "\n")
    arquivo.close()

    print("Usuário cadastrado com sucesso!")


def login():
    linha()
    print("LOGIN")
    linha()

    usuario = input("Digite seu usuário: ").strip()
    senha = input("Digite sua senha: ").strip()

    open(ARQ_USUARIOS, "a").close()

    arquivo = open(ARQ_USUARIOS, "r")
    linhas = arquivo.readlines()
    arquivo.close()

    for l in linhas:
        partes = l.strip().split(";")

        if len(partes) >= 2:
            u, s = partes[0], partes[1]

            if u == usuario and s == senha:
                print("Login realizado com sucesso!")
                return usuario

    print("Usuário ou senha incorretos.")
    return None


# ================= VÍDEOS =================

def inicializar_videos():
    open(ARQ_VIDEOS, "a").close()

    arquivo = open(ARQ_VIDEOS, "r")
    conteudo = arquivo.read()
    arquivo.close()

    if conteudo.strip() == "":
        arquivo = open(ARQ_VIDEOS, "w")

        arquivo.write("Python para Iniciantes;0;10:35\n")
        arquivo.write("Aprendendo Lógica;0;08:20\n")
        arquivo.write("Criando um Jogo Simples;0;12:45\n")
        arquivo.write("Introdução ao HTML;0;07:10\n")
        arquivo.write("CSS Básico;0;09:50\n")
        arquivo.write("JavaScript Inicial;0;11:30\n")

        arquivo.close()


def listar_videos():
    linha()
    print("LISTA DE VÍDEOS")
    linha()

    arquivo = open(ARQ_VIDEOS, "r")
    videos = arquivo.readlines()
    arquivo.close()

    if len(videos) == 0:
        print("Nenhum vídeo encontrado!")
        return

    for i, v in enumerate(videos, start=1):
        partes = v.strip().split(";")

        if len(partes) == 3:
            titulo, likes, duracao = partes

            print(f"{i}. {titulo}")
            print(f"   👍 {likes} | ⏱ {duracao}")
            linha()


def buscar_video():
    nome = input("Digite o nome do vídeo: ").lower()

    arquivo = open(ARQ_VIDEOS, "r")
    videos = arquivo.readlines()
    arquivo.close()

    encontrou = False

    for v in videos:
        partes = v.strip().split(";")

        if len(partes) == 3:
            titulo, likes, duracao = partes

            if nome in titulo.lower():
                print(f"{titulo}")
                print(f"👍 {likes} | ⏱ {duracao}")
                linha()
                encontrou = True

    if not encontrou:
        print("Nenhum vídeo encontrado.")


def curtir_video():
    nome = input("Qual vídeo deseja curtir: ")

    arquivo = open(ARQ_VIDEOS, "r")
    videos = arquivo.readlines()
    arquivo.close()

    novos = []
    encontrou = False

    for v in videos:
        partes = v.strip().split(";")

        if len(partes) == 3:
            titulo, likes, duracao = partes

            if titulo.lower() == nome.lower():
                likes = str(int(likes) + 1)
                encontrou = True

            novos.append(titulo + ";" + likes + ";" + duracao)

    arquivo = open(ARQ_VIDEOS, "w")
    for v in novos:
        arquivo.write(v + "\n")
    arquivo.close()

    if encontrou:
        print("Curtido!")
    else:
        print("Vídeo não encontrado.")


def descurtir_video():
    nome = input("Qual vídeo deseja descurtir: ")

    arquivo = open(ARQ_VIDEOS, "r")
    videos = arquivo.readlines()
    arquivo.close()

    novos = []
    encontrou = False

    for v in videos:
        partes = v.strip().split(";")

        if len(partes) == 3:
            titulo, likes, duracao = partes

            if titulo.lower() == nome.lower():
                if int(likes) > 0:
                    likes = str(int(likes) - 1)
                encontrou = True

            novos.append(titulo + ";" + likes + ";" + duracao)

    arquivo = open(ARQ_VIDEOS, "w")
    for v in novos:
        arquivo.write(v + "\n")
    arquivo.close()

    if encontrou:
        print("Descurtido!")
    else:
        print("Vídeo não encontrado.")


# ================= FAVORITOS =================

def adicionar_favorito(usuario):
    video = input("Nome do vídeo: ")

    arquivo = open(ARQ_FAVORITOS, "a")
    arquivo.write(usuario + ";" + video + "\n")
    arquivo.close()

    print("Adicionado aos favoritos!")


def ver_favoritos(usuario):
    open(ARQ_FAVORITOS, "a").close()

    arquivo = open(ARQ_FAVORITOS, "r")
    linhas = arquivo.readlines()
    arquivo.close()

    linha()
    print("SEUS FAVORITOS")
    linha()

    encontrou = False

    for l in linhas:
        partes = l.strip().split(";")

        if len(partes) == 2:
            u, v = partes
            if u == usuario:
                print(f"- {v}")
                encontrou = True

    if not encontrou:
        print("Nenhum favorito ainda.")


def remover_favorito(usuario):
    video = input("Qual vídeo remover: ")

    arquivo = open(ARQ_FAVORITOS, "r")
    linhas = arquivo.readlines()
    arquivo.close()

    novos = []
    removido = False

    for l in linhas:
        partes = l.strip().split(";")

        if len(partes) == 2:
            u, v = partes

            if not (u == usuario and v.lower() == video.lower()):
                novos.append(l.strip())
            else:
                removido = True

    arquivo = open(ARQ_FAVORITOS, "w")
    for l in novos:
        arquivo.write(l + "\n")
    arquivo.close()

    if removido:
        print("Removido!")
    else:
        print("Favorito não encontrado.")


# ================= MENU =================

def menu(usuario):
    while True:
        linha()
        print(f"🎬 FEI-TV | Usuário: {usuario}")
        linha()
        print("1 - Listar vídeos")
        print("2 - Buscar vídeo")
        print("3 - Curtir vídeo")
        print("4 - Descurtir vídeo")
        print("5 - Adicionar aos favoritos")
        print("6 - Ver favoritos")
        print("7 - Remover favorito")
        print("0 - Sair")
        linha()

        op = input("Escolha: ")

        if op == "1":
            listar_videos()

        elif op == "2":
            buscar_video()

        elif op == "3":
            curtir_video()

        elif op == "4":
            descurtir_video()

        elif op == "5":
            adicionar_favorito(usuario)

        elif op == "6":
            ver_favoritos(usuario)

        elif op == "7":
            remover_favorito(usuario)

        elif op == "0":
            print("Saindo...")
            break

        else:
            print("Opção inválida!")


# ================= MAIN =================

def main():
    inicializar_videos()

    print("SEJA BEM-VINDO AO FEI-TV!")

    usuario = login()

    if not usuario:
        print("Você precisa se cadastrar.")
        cadastroUser()

        print("Faça login novamente:")
        usuario = login()

    if usuario:
        menu(usuario)


main()